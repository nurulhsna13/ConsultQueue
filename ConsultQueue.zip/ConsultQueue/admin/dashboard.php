<?php
session_start();
include "../config/koneksi.php";

if(!isset($_SESSION['admin'])){
    header("Location: ../login.php");
    exit;
}

$dosen=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM dosen"));
$mahasiswa=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM mahasiswa"));
$jadwal=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM jadwal"));
$antrian=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM antrian"));
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Dashboard Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">

<div class="container">

<a class="navbar-brand">

ConsultQueue Admin

</a>

<a href="../logout.php" class="btn btn-light">

Logout

</a>

</div>

</nav>

<div class="container mt-5">

<div class="row">

<div class="col-md-3">

<div class="card shadow">

<div class="card-body text-center">

<i class="bi bi-person-workspace fs-1 text-primary"></i>

<h5>Dosen</h5>

<h2><?= $dosen ?></h2>

<a href="dosen.php" class="btn btn-primary">

Kelola

</a>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow">

<div class="card-body text-center">

<i class="bi bi-calendar-check fs-1 text-success"></i>

<h5>Jadwal</h5>

<h2><?= $jadwal ?></h2>

<a href="jadwal.php" class="btn btn-success">

Kelola

</a>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow">

<div class="card-body text-center">

<i class="bi bi-people fs-1 text-warning"></i>

<h5>Mahasiswa</h5>

<h2><?= $mahasiswa ?></h2>

<a href="mahasiswa.php" class="btn btn-warning">

Kelola

</a>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow">

<div class="card-body text-center">

<i class="bi bi-ticket-perforated fs-1 text-danger"></i>

<h5>Antrian</h5>

<h2><?= $antrian ?></h2>

<a href="antrian.php" class="btn btn-danger">

Kelola

</a>

</div>

</div>

</div>

</div>

<div class="mt-5">

<a href="laporan.php" class="btn btn-dark">

Cetak Laporan

</a>

</div>

</div>

</body>

</html>